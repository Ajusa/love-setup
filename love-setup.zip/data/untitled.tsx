<?xml version="1.0" encoding="UTF-8"?>
<tileset name="asdf" tilewidth="64" tileheight="64" spacing="4" tilecount="1036" columns="37">
 <image source="../images/roguelikeCity_magenta.png" width="2512" height="1900"/>
</tileset>
