<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiled" tilewidth="64" tileheight="64" tilecount="1767" columns="57">
 <image source="../images/roguelikeSheet_transparent.png" width="3648" height="1984"/>
</tileset>
